import pluginBase from '../base';
import adapterConfig from './config';
import downAdapter from 'fruitdown';

pluginBase(adapterConfig, downAdapter);