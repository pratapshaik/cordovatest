export default {
  name: 'memory',
  valid: function () {
    return true;
  },
  use_prefix: false
};