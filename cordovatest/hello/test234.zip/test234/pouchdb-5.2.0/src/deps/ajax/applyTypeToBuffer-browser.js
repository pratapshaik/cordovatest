// the blob already has a type; do nothing
var res = function () {};

export default res;