import buffer from '../binary/buffer';

function defaultBody() {
  return new buffer('', 'binary');
}

export default defaultBody;