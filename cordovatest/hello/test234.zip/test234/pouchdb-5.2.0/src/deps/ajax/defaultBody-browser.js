function defaultBody() {
  return '';
}

export default defaultBody;