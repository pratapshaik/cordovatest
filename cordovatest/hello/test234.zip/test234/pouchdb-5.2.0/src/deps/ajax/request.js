// May seem redundant, but this is to allow switching with
// request-browser.js.
export default require('request');