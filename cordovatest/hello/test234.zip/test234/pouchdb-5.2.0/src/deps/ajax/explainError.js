// We assume Node users don't need to see this warning
var res = function () {};

export default res;
