//this solely exists so we can exclude it in browserify
export default Buffer;