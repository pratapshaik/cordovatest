// hey guess what, we don't need this in the browser
export default {};