import leveldb from './adapters/leveldb/index';

export default {
  leveldb: leveldb
};