'use strict';

// allow external plugins to require('pouchdb/extras/genReplicationId')
module.exports = require('../lib/extras/generateReplicationId');