'use strict';

// allow external plugins to require('pouchdb/extras/ajax')
module.exports = require('../lib/extras/ajax');