'use strict';

// allow external plugins to require('pouchdb/extras/checkpointer')
module.exports = require('../lib/extras/checkpointer');