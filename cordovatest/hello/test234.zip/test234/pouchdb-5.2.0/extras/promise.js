'use strict';

// allow external plugins to require('pouchdb/extras/promise')
module.exports = require('../lib/extras/promise');